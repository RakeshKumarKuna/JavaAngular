package com.main.RestTemplateEx;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

@Component
public class RestTemplateCommunication implements ApplicationRunner {
	@Autowired
	public RestTemplate template;

	@Override
	public void run(ApplicationArguments args) throws Exception {

		String url = "http://localhost:8080/api/v1/getbill";
		
		ResponseEntity<String> responce = template.getForEntity(url, String.class);
		
		System.out.println(responce.getBody());
		System.out.println(responce.getStatusCodeValue());
		System.out.println(responce.getHeaders());
		System.out.println("payment done");
		String res="payment done";
		String responceurl = "http://localhost:8080/api/v1/responce/{data}";
         template.getForEntity(responceurl, String.class,Map.of("data",res));
	}
}
