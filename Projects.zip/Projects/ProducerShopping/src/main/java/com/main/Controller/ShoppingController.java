package com.main.Controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1")
public class ShoppingController {
	List<Integer> list = new ArrayList();
	int totalbill = 0;

	@GetMapping("/addcart/{cartitems}")
	public void addCart(@PathVariable("cartitems") int cartitems) {
		list.add(cartitems);
		System.out.println(cartitems);
	}

	@GetMapping("/getbill")
	public ResponseEntity<String> addCart() {

		list.forEach(data -> {
			totalbill = totalbill + data;
		});
		return new ResponseEntity("total bill is " + totalbill, HttpStatus.OK);
	}

	@GetMapping("/responce/{data}")
	public void responce(@PathVariable String data) {
     System.out.println("recevied data "+data);
	}

}